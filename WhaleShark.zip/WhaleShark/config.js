/*eslint-disable*/

/*
 * 설정 파일
 */

module.exports = {
	server_port: 3000,
    db_connectionLimit : 10, 
    db_host     : 'localhost',
    db_user     : 'root',
    db_password : 'skskfdl12',
    db_database : 'sample',
    db_debug    :  false,
    route_info: [
	    //===== User =====//
	    {file:'./function', path:'/process/login', method:'login', type:'post'}					// user.login 
	    ,{file:'./function', path:'/process/adduser', method:'adduser', type:'post'}				// user.adduser 
	]
}